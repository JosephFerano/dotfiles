## dotfiles

### Hardware
- [System76 Serval](https://system76.com/laptops/serval)
- [Ergodox-Ez](https://ergodox-ez.com/) with custom layout. TODO: Link to my configuration.

### Main environment
- Pop_OS 
- i3wm
- Zsh Shell
- Alacritty GPU-accelerated terminal
- Jetbrains IdeaVim (Mainly .NET for work)
- Neovim for general text editing
- Cmus for music
- Ranger file manager
- Tig and fish aliases for git

### Editors
I have an old `vimrc` and emacs `init.el`. The former I used for over 4 years,
the latter I played around with it for a few months. I'm trying to use
kakoune now, but keeping them for reference. Also have a kakoune rc, but I stopped using it.
