#!/bin/sh
xrandr \
--output HDMI-0 --off \
--output DP-4 --off \
--output DP-2 --off \
--output DP-3 	         --mode 1920x1080 --pos 0x0    --panning 1920x1080+0+0 --dpi 96 \
--output DP-1  --primary --mode 1920x1080 --pos 1920x0 --panning 1920x1080+1920+0 --dpi 96 \
--output DP-0            --mode 1920x1080 --pos 3840x0 --panning 1920x1080+3840+0 --dpi 96
i3-msg "workspace 1; move workspace to output DP-3;
	workspace music; move workspace to output DP-0;
	workspace 0:chat; move workspace to output DP-1;
	workspace 2; move workspace to output DP-3;
	workspace 3; move workspace to output DP-1;
	workspace 4; move workspace to output DP-1;
	workspace 5; move workspace to output DP-1;
	workspace 6; move workspace to output DP-1;
	workspace 3"
