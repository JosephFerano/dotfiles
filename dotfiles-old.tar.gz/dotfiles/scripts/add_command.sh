#!/bin/bash

if [ -z "$1" ];
then
    echo "Provide a command, alternative pass the -l to add the last command in history"
    exit 1
fi

file=$HOME/School/CCOM4088-CyberSecurity/commands


if [ "$1" = "-l" ]
then
    tail ~/.histfile -n 2 | head -n 1 | sed 's/^.*;//' >> $file
else
    echo "$1" >> $file
fi

tail $file
