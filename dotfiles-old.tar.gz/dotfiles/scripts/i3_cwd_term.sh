#!/bin/bash
ACTIVE_WINDOW=$(xdpyinfo | grep focus | cut -f4 -d " ")
ACTIVE_WM_CLASS=$(xprop -id $ACTIVE_WINDOW | grep WM_CLASS)
if [[ $ACTIVE_WM_CLASS == *"Alacritty"* ]]
then
    # Get PID. If _NET_WM_PID isn't set, bail.
    PID=$(xprop -id $ACTIVE_WINDOW | grep _NET_WM_PID | grep -oP "\d+")
    if [[ "$PID" == "" ]]
    then
        alacritty
    fi
    # Get first child of terminal
    CHILD_PID=$(pgrep -P $PID)
    if [[ "$PID" == "" ]]
    then
        alacritty
    fi
    # Get current directory of child. The first child should be the shell.
    SHELL_CWD=$(readlink -e "/proc/${CHILD_PID}/cwd")
    # Start alacritty with the working directory
    alacritty --working-directory $SHELL_CWD
else
    alacritty
fi

# alacritty --working-directory "$(readlink -e /proc/"$(pgrep -P "$(xdo pid)" | tail -n 1)"/cwd)"
