#!/bin/bash
xset r rate 270 60
setxkbmap us -variant altgr-intl
