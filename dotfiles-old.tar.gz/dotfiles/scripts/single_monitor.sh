#!/bin/sh
xrandr  --output DP-0 --mode 1920x1080 --pos 0x0 --dpi 96 \
	--output DP-4 --primary --mode 1920x1080 --pos 1920x0 --right-of DP-0 --dpi 96
i3-msg "workspace music;  move workspace to output DP-0;
	workspace 0:chat; move workspace to output DP-4;
	workspace 1;      move workspace to output DP-4;
	workspace 2;      move workspace to output DP-4;
	workspace 3;      move workspace to output DP-4;
	workspace 4;      move workspace to output DP-4;
	workspace 5;      move workspace to output DP-4;
	workspace 6;      move workspace to output DP-4;
	workspace 7;      move workspace to output DP-4;
	workspace 3"
